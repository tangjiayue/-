package org.csu.softwaremetric;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareMetricApplicationTests {

      @Test
      void contextLoads() {
      }

}
