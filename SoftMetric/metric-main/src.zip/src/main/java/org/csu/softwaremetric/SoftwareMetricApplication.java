package org.csu.softwaremetric;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftwareMetricApplication {

      public static void main(String[] args) {
            SpringApplication.run(SoftwareMetricApplication.class, args);
      }

}
