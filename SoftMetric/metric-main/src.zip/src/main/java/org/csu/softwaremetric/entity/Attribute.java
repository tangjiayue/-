package org.csu.softwaremetric.entity;

import lombok.Data;

@Data
public class Attribute {
    private String name;
    private String visibility;
}
