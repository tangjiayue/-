package org.csu.softwaremetric.entity;

import lombok.Data;

@Data
public class Parameter {
    private String name;
    private String className;
}
